###演示地址###
[演示地址](http://mufeng.me/hermit-for-wordpress.html "Hermit 演示地址")


###Hermit 更新历史###

2014.2.11  |  1.0.0  (14-2-11)  
1.  最初1.0.0版本发布


###感谢开源项目###
[SoundManager 2](https://github.com/scottschiller/SoundManager2 "SoundManager 2")


如果你对这个插件感兴趣, 敬请关注:  
[作者的博客](http://mufeng.me/ "作者的博客")  
[插件发布页](http://mufeng.me/hermit-for-wordpress.html "插件发布页")
