module.exports = {
  entry: "./lib/drmariojs.js",
  output: {
  	filename: "./lib/bundle.js"
  },
  devtool: 'source-map',
};
