# SSR Example

**Note:** This example uses Meteor. Meteor can be downloaded [here](https://www.meteor.com/install).

```
meteor npm install
meteor npm start
```

Access: http://localhost:3000
