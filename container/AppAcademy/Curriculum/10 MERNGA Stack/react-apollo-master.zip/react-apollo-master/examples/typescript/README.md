# Typescript Example

```
npm install
npm start
```
