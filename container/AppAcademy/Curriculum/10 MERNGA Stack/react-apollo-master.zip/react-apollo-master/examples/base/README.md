# Base Example

```
npm install
npm start
```
