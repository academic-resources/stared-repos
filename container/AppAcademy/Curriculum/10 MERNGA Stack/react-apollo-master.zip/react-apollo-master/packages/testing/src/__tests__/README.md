**Note:** `MockedProvider` tests are currently run from the `@apollo/react-hoc`
project, as they have a hard dependency on the `graphql` HOC. They will be
refactored, and eventually stored here.
