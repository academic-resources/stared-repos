class Piece


  def inspect
    'x'
  end

end

class NullPiece < Piece

  def inspect
    '_'
  end


end