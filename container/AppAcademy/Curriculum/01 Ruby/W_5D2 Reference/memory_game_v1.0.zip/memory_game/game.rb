require_relative "board.rb"
require "byebug"

class Game

    def initialize
        @board = Board.new
        @board.populate
        @previous_guess
    end

    def play
        until self.over
            @board.render
            self.make_guess
            sleep(2)
            system("clear")
        end
        puts "Congratulations!  Don't do drugs!"
        sleep(2)
    end

    def over
        @board.won?
    end

    def make_guess
        @previous_guess = self.prompt
        next_guess = self.prompt
        if @board[@previous_guess] == @board[next_guess]
            puts "Match!"
        else
            puts "No Match!"
            @board[@previous_guess].hide
            @board[next_guess].hide
        end
    end

    def prompt
        puts "Please enter an x-coordinate for your guess: "
        guess_x = gets.chomp.to_i
        puts "Please enter a y-coordinate for your guess: "
        guess_y = gets.chomp.to_i
        pos = [guess_y, guess_x]
        guess = @board.reveal(pos)
        system("clear")
        @board.render
        return pos
    end

end