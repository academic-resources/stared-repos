require_relative "game.rb"

memory = Game.new
memory.play