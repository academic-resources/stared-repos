#Problem 1: 

def sum_recur(array)
end

#Problem 2: 

def includes?(array, target)
end

# Problem 3: 

def num_occur(array, target)
end

# Problem 4: 

def add_to_twelve?(array)
end

# Problem 5: 

def sorted?(array)
end

# Problem 6: 

def reverse(string)
end
