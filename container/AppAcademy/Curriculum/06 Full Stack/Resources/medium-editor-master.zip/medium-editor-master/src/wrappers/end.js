    return MediumEditor;
}()));
