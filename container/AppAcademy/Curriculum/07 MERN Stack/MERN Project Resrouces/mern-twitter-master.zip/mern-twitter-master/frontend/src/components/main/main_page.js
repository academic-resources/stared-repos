import React from 'react';

class MainPage extends React.Component {

  render() {
    return (
      <div>
        <p>A Twitter Clone</p>
        <footer>
          Copyright &copy; 2019 Chirper
        </footer>
      </div>
    );
  }
}

export default MainPage;