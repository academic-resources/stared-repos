
const partyHeader = document.getElementById('party');

export const htmlGenerator = (string, htmlElement) => {

};

htmlGenerator('Party Time.', partyHeader);