module.exports = {
  entry: "./lib/main.js",
  output: {
    path: __dirname,
    filename: "./lib/jquery_lite.js"
	},
	devtool: "source-map"
};
