class Course < ApplicationRecord
end
