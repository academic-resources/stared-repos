class Enrollment < ApplicationRecord
end
