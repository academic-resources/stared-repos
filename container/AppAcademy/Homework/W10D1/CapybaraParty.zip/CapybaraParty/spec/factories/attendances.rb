# == Schema Information
#
# Table name: attendances
#
#  id          :integer          not null, primary key
#  capy_id :integer
#  party_id    :string
#  created_at  :datetime         not null
#  updated_at  :datetime         not null
#

FactoryBot.define do
  factory :attendance do

  end

end
