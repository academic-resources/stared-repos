# Videos

* [00-user-models](https://vimeo.com/93097977)
  ([DIFF](https://github.com/appacademy/AuthVideoDemo/compare/init-commit...00-user-models))
* [01-basic-sessions](https://vimeo.com/93097978)
  ([DIFF](https://github.com/appacademy/AuthVideoDemo/compare/00-user-models...01-basic-sessions))
* [02-password-digest](https://vimeo.com/93097979)
  ([DIFF](https://github.com/appacademy/AuthVideoDemo/compare/01-basic-sessions...02-password-digest))
* [03-password-pseudo-attribute](https://vimeo.com/93100190)
  ([DIFF](https://github.com/appacademy/AuthVideoDemo/compare/02-password-digest...03-password-pseudo-attribute))
* [04-session-token](https://vimeo.com/93101442)
  ([DIFF](https://github.com/appacademy/AuthVideoDemo/compare/03-password-pseudo-attribute...04-session-token))
* [05-bcrypt](https://vimeo.com/93104232)
  ([DIFF](https://github.com/appacademy/AuthVideoDemo/compare/04-session-token...05-bcrypt))
* [06-csrf-attack](https://vimeo.com/93114286)
  ([DIFF](https://github.com/appacademy/AuthVideoDemo/compare/05-bcrypt...06-csrf-attack))
* [07-implement-csrf-protection](https://vimeo.com/93114288)
  ([DIFF](https://github.com/appacademy/AuthVideoDemo/compare/06-csrf-attack...07-implement-csrf-protection))
* [08-rails-csrf-methods](https://vimeo.com/93114287)
  ([DIFF](https://github.com/appacademy/AuthVideoDemo/compare/07-implement-csrf-protection...08-rails-csrf-methods))

## TODO

* CSRF
