# w4: IntroRailsVideoDemo

* [Vimeo Album](https://vimeo.com/album/2953690/sort:alphabetical)
    * Password: `go_video_go`
* Direct links:
    * [03-basic-rails-routing](https://vimeo.com/100267303)
    * [04-strong-params](https://vimeo.com/100267304)
    * [05-nested-resources](https://vimeo.com/100267305)
