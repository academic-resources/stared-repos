import React from "react";
import { Route } from "react-router-dom";
import PostIndex from "./posts/PostIndex";

const App = () => (
  <div>
    <h1>Hellloooo World!</h1>
    {/* <Route path="/" component={PostIndex} /> */}
  </div>
);

export default App;
